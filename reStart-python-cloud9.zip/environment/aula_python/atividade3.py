firststring = "walter"
secondstring ="fall"
thirdstring = firststring +secondstring 
print(thirdstring)

nome = input("what is you nome ? ")
print(nome)

color = input("what is your favorite color? ")
animal = input("what is your favorite animal? ")
print("{}, you like a {} {}!".format(nome,color,animal))