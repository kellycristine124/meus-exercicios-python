print("Python has three numeric types: int, float, and complex")

meuvalor = 1
print(meuvalor)
print(type(meuvalor))
print(str(meuvalor) + "is of the data type" + str(type(meuvalor)))

meuvalor2 = 3.14
print(meuvalor2)
print(type(meuvalor2))
print(str(meuvalor2) + "is of the data type" + str(type(meuvalor2)))

meuvalor3 = 5j
print(meuvalor3)
print(type(meuvalor3)) 
print(str(meuvalor3) + "is of the data type" + str(type(meuvalor3)))

meuvalor4 = True 
print(meuvalor4)
print(type(meuvalor4))
print(str(meuvalor4) + "is of the data type" + str(type(meuvalor4)))

meuvalor5 = False
print(meuvalor5)
print(type(meuvalor5))
print(str(meuvalor5) + "is of data type" + str(type(meuvalor5)))

meutexto = "the is a string"
print(meutexto)
print(type(meutexto))
print(str(meutexto) +"is of date type " + str(type(meutexto)))



