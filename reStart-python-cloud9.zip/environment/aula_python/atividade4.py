minhalistadefruta = [ "banana" , "morango" , "uva"]
print(minhalistadefruta)
print(type(minhalistadefruta))
print(minhalistadefruta[0])
print(minhalistadefruta[1])
print(minhalistadefruta[2])

meurespostafinal = ("apple", "banana", "pineapple")
print(meurespostafinal)
print(type(meurespostafinal))
print(meurespostafinal[0])
print(meurespostafinal[1])
print(meurespostafinal[2])

myfrutafavoritadicionario = { 
    "akua" : "apple" ,
    "saanvi" : "banana" ,
    "paulo" : "prineapple" 
    }

myfrutafavoritadicionario
print(type(myfrutafavoritadicionario))
print(myfrutafavoritadicionario ["akua"])
print(myfrutafavoritadicionario["saanvi"])
print(myfrutafavoritadicionario["paulo"])